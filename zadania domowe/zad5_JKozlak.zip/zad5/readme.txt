Kod z maina wrzuciłem do Colab-a. Wystarczy wejść w link i odpalić :)

https://colab.research.google.com/drive/1ESTWRUd1T1SmPUF8GBgPtSUOGDP4OYfd#scrollTo=YfVvKE7mTqUP
