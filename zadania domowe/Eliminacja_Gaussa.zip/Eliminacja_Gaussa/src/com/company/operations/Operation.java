package com.company.operations;

public interface Operation {
    // why interface? don't know
    // maybe to delete, maybe to use in future

    void execute();

}
